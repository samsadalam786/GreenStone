<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US">
<head>
    <meta charset="utf-8">
    <title>Kumawat Construction Company - Building construction company in jaipur</title>
    <meta name="description" content="building construction company in jaipur rajasthan, building constitution in jaipur building contractions in jaipur, building contractor in jaipur, jaipur builders, construction companies in jaipur, constructeur in jaipur, building construction in jaipur">
    <meta name="keywords" content="building construction company in jaipur rajasthan, building constitution in jaipur building contractions in jaipur, building contractor in jaipur, jaipur builders, construction companies in jaipur, constructeur in jaipur, building construction in jaipur">
    <base href="https://www.kumawatconstructions.com/">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- Theme Style -->
    <link rel="stylesheet" type="text/css" href="style.css">
    <!-- Colors -->
    <link rel="stylesheet" type="text/css" href="assets/css/colors/color1.css" id="colors">
    <link rel="stylesheet" type="text/css" href="assets/css/toastr.min.css">
    <!-- Favicon and Touch Icons  -->
    <link rel="apple-touch-icon-precomposed" href="assets/icon/apple-touch-icon-158-precomposed.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="shortcut icon" href="/administrator/assets/dist/img/headerimage/300x3001111.png">
    <!--[if lt IE 9]>
        <script src="javascript/html5shiv.js"></script>
        <script src="javascript/respond.min.js"></script>
    <![endif]-->
</head>

<body class="header-fixed page no-sidebar header-style-3 topbar-style-3 site-header-absolute menu-has-search">
<div id="wrapper" class="animsition">
    <div id="page" class="clearfix">
        <!-- Header Wrap -->
        <div id="site-header-wrap">
            <!-- Top Bar -->        
            <div id="top-bar">
                <div id="top-bar-inner" class="container">
                    <div class="top-bar-inner-wrap">
                        <div class="top-bar-content">
                            <div class="inner">
                            	<span class="address content">67-A, Sindhu Nager, Murlipura</span>
                                <span class="phone content">+91 - 99290 94686, +91 - 70146 83732, +91 - 83021 43406</span>
                            </div>                            
                        </div><!-- /.top-bar-content -->

                        <div class="top-bar-socials">
                            <div class="inner">
                                <span class="text">Follow us:</span>
                                <span class="icons">
                                	<a href="https://www.facebook.com/KCCJPR/"><i class="fa fa-facebook"></i></a>
                                    <a href="-"><i class="fa fa-twitter"></i></a>
                                    <a href="-"><i class="fa fa-youtube"></i></a>
                                    <a href="https://www.instagram.com/suresh_kuku/"><i class="fa fa-instagram"></i></a>
                                </span>
                            </div>
                        </div><!-- /.top-bar-socials -->
                    </div>                    
                </div>
            </div><!-- /#top-bar -->

            <!-- Header -->
            <header id="site-header">
                <div id="site-header-inner" class="container">                    
                    <div class="wrap-inner clearfix">
                        <div id="site-logo" class="clearfix">
                            <div id="site-log-inner">
                                <a href="index.php" rel="home" class="main-logo">
                                    <img src="/administrator/assets/dist/img/logo/500x50011.png" alt="Kumawat Construction Company" width="169" height="39" data-retina="/administrator/assets/dist/img/logo/500x50011.png" data-width="169" data-height="39">
                                </a>
                            </div>
                        </div><!-- /#site-logo -->

                        <div class="mobile-button">
                            <span></span>
                        </div><!-- /.mobile-button -->

                        <nav id="main-nav" class="main-nav">
                            <ul id="menu-primary-menu" class="menu">
                                <li class="menu-item current-menu-item">
                                    <a href="index.php">HOME</a>
                                </li>
                                <li class="menu-item ">
                                    <a href="aboutus">ABOUT US </a>
                                </li>
                                <li class="menu-item ">
                                    <a href="services">SERVICES</a>
                                </li>
                                <li class="menu-item" >
                                    <a href="projects">PROJECTS</a>
                                </li>
                                <li class="menu-item" >
                                    <a href="gallery">GALLERY</a>
                                </li>
                                <li class="menu-item ">
                                    <a href="blog">BLOGS</a>
                                </li>
                                <li class="menu-item ">
                                    <a href="contactus">CONTACT</a>
                                </li>
                            </ul>
                        </nav><!-- /#main-nav -->

                        <div id="header-search">
                            <a href="#" class="header-search-icon">
                                <span class="search-icon fa fa-search">
                                </span>
                            </a>

                            <form role="search" method="get" class="header-search-form" action="#">
                                <label class="screen-reader-text">Search for:</label>
                                <input type="text" value="" name="s" class="header-search-field" placeholder="Search...">
                                <button type="submit" class="header-search-submit" title="Search">Search</button>
                            </form>
                        </div><!-- /#header-search -->
                    </div><!-- /.wrap-inner -->                    
                </div><!-- /#site-header-inner -->
            </header><!-- /#site-header -->
        </div><!-- #site-header-wrap -->        <!-- Main Content -->
        <div id="main-content" class="site-main clearfix">
            <div id="content-wrap">
                <div id="site-content" class="site-content clearfix">
                    <div id="inner-content" class="inner-content-wrap">
                       <div class="page-content">
                           <!-- SLIDER -->
                            <div class="rev_slider_wrapper fullwidthbanner-container">
                                <div id="rev-slider2" class="rev_slider fullwidthabanner">
                                    <ul>
                                                                                <!-- Slide 1 -->
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <img src="/administrator/assets/dist/img/slider/1.jpg" alt="" data-bgposition="center center" data-no-retina>
                                           
                                            <!-- Layers -->
                                            <div class="tp-caption tp-resizeme font-heading font-weight-600 " style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-90','-90','-90','-90']"
                                                data-fontsize="['20','20','20','16']"
                                                data-lineheight="['70','70','40','24']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="700" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                A GLOBAL LEADER IN INFRASTRUCTURE                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700"
                                                 style="color: navy;" data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','-20']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                we will be happy                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700" style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['45','45','45','45']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                to take care of your work                                            </div>
                                        </li>
                                                                                <!-- Slide 1 -->
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <img src="/administrator/assets/dist/img/slider/2.jpg" alt="" data-bgposition="center center" data-no-retina>
                                           
                                            <!-- Layers -->
                                            <div class="tp-caption tp-resizeme font-heading font-weight-600 " style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-90','-90','-90','-90']"
                                                data-fontsize="['20','20','20','16']"
                                                data-lineheight="['70','70','40','24']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="700" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                A GLOBAL LEADER IN INFRASTRUCTURE                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700"
                                                 style="color: navy;" data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','-20']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                we will be happy                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700" style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['45','45','45','45']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                to take care of your work                                            </div>
                                        </li>
                                                                                <!-- Slide 1 -->
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <img src="/administrator/assets/dist/img/slider/3.jpg" alt="" data-bgposition="center center" data-no-retina>
                                           
                                            <!-- Layers -->
                                            <div class="tp-caption tp-resizeme font-heading font-weight-600 " style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-90','-90','-90','-90']"
                                                data-fontsize="['20','20','20','16']"
                                                data-lineheight="['70','70','40','24']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="700" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                A GLOBAL LEADER IN INFRASTRUCTURE                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700"
                                                 style="color: navy;" data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','-20']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                we will be happy                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700" style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['45','45','45','45']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                to take care of your work                                            </div>
                                        </li>
                                                                                <!-- Slide 1 -->
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <img src="/administrator/assets/dist/img/slider/4.jpg" alt="" data-bgposition="center center" data-no-retina>
                                           
                                            <!-- Layers -->
                                            <div class="tp-caption tp-resizeme font-heading font-weight-600 " style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-90','-90','-90','-90']"
                                                data-fontsize="['20','20','20','16']"
                                                data-lineheight="['70','70','40','24']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="700" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                A GLOBAL LEADER IN INFRASTRUCTURE                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700"
                                                 style="color: navy;" data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','-20']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                we will be happy                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700" style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['45','45','45','45']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                to take care of your work                                            </div>
                                        </li>
                                                                                <!-- Slide 1 -->
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <img src="/administrator/assets/dist/img/slider/5.jpg" alt="" data-bgposition="center center" data-no-retina>
                                           
                                            <!-- Layers -->
                                            <div class="tp-caption tp-resizeme font-heading font-weight-600 " style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-90','-90','-90','-90']"
                                                data-fontsize="['20','20','20','16']"
                                                data-lineheight="['70','70','40','24']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="700" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                A GLOBAL LEADER IN INFRASTRUCTURE                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700"
                                                 style="color: navy;" data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','-20']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                we will be happy                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700" style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['45','45','45','45']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                to take care of your work                                            </div>
                                        </li>
                                                                                <!-- Slide 1 -->
                                        <li data-transition="random">
                                            <!-- Main Image -->
                                            <img src="/administrator/assets/dist/img/slider/slideNew1.jpg" alt="" data-bgposition="center center" data-no-retina>
                                           
                                            <!-- Layers -->
                                            <div class="tp-caption tp-resizeme font-heading font-weight-600 " style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-90','-90','-90','-90']"
                                                data-fontsize="['20','20','20','16']"
                                                data-lineheight="['70','70','40','24']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="700" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                A GLOBAL LEADER IN INFRASTRUCTURE                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700"
                                                 style="color: navy;" data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['-20','-20','-20','-20']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;"
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                we will be happy                                            </div>

                                            <div class="tp-caption tp-resizeme font-heading font-weight-700" style="color: navy;"
                                                data-x="['left','left','left','center']" data-hoffset="['0','0','0','0']"
                                                data-y="['middle','middle','middle','middle']" data-voffset="['45','45','45','45']"
                                                data-fontsize="['52','52','42','32']"
                                                data-lineheight="['65','65','45','35']"
                                                data-width="full"
                                                data-height="none"
                                                data-whitespace="normal"
                                                data-transform_idle="o:1;"
                                                data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                                                data-transform_out="y:[100%];s:1000;e:Power2.easeInOut;s:1000;e:Power2.easeInOut;" 
                                                data-mask_in="x:0px;y:[100%];" 
                                                data-mask_out="x:inherit;y:inherit;" 
                                                data-start="1000" 
                                                data-splitin="none" 
                                                data-splitout="none" 
                                                data-responsive_offset="on">
                                                to take care of your work                                            </div>
                                        </li>
                                                                                <!-- /End Slide  -->
                                    </ul>
                                </div> 
                            </div>
                            <!-- END SLIDER -->

                            <!-- SERVICES -->
                            <div class="row-services">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="themesflat-spacer clearfix" data-desktop="60" data-mobile="60" data-smobile="60"></div>
                                            <div class="themesflat-headings style-1 text-center clearfix">
                                                <h2 class="heading">OUR SERVICES</h2>
                                                <div class="sep has-icon width-125 clearfix">
                                                    <div class="sep-icon">
                                                        <span class="sep-icon-before sep-center sep-solid"></span>
                                                        <span class="icon-wrap"><i class="autora-icon-build"></i></span>
                                                        <span class="sep-icon-after sep-center sep-solid"></span>
                                                    </div>
                                                </div>                                                
                                            </div>
                                            <div class="themesflat-spacer clearfix" data-desktop="27" data-mobile="35" data-smobile="35"></div>
                                            <div class="themesflat-carousel-box has-arrows arrow-center offset-v-111 offset-h-21 arrow-circle arrow-style-2 data-effect clearfix" data-gap="30" data-column="3" data-column2="2" data-column3="1" data-auto="true">
                                                <div class="owl-carousel owl-theme">
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/cracks-250x250.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/9">all type of crackes solution avilable</a></h5>
                                                                    <p>we have all type&nbsp;of building crackes solution. if you have any type of crack contact us</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/9">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/jquar-min-1.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/8">jequar&#039;s sainatry products</a></h5>
                                                                    <p>we provide the jequar&#39;s brands sainatry products like wc, washbasin, bathroom shower, diverter,</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/8">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/onur-marble-granite-home-ss-06.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/7">marval grenite installaion</a></h5>
                                                                    <p>marval grenite related all of services.</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/7">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/lighting design service_0.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/6">light sevices</a></h5>
                                                                    <p>we have all of solutions for your home lighting&nbsp;and gat sevice quickly.</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/6">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/WhatsApp Image 2020-09-02 at 15.21.25.jpeg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/5">All Type Of Construction Managment</a></h5>
                                                                    <p>We work closely with architects to understand the project, and ultimately develop a targeted...</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/5">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/IMG-20190626-WA0024.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/4">build your home according to you</a></h5>
                                                                    <p>We develop and understand project expectations and then manage those needs with a design team...</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/4">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/images.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/3">sanitary services</a></h5>
                                                                    <p>we have all type of sanatry related items.&nbsp;</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/3">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/sharing-facebook.png" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/2">Construction With JK SUPER CEMENT</a></h5>
                                                                    <p>We have Tieup with JK Super cement that&#39;s make super Quality to Make Great Qualitier.</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/2">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                    
                                                    <div class="themesflat-image-box style-2 clearfix">
                                                        <div class="image-box-item">
                                                            <div class="inner">
                                                                <div class="thumb data-effect-item">
                                                                    <img src="/administrator/assets/dist/img/events/Web_Photo_Editor.jpg" alt="Image">
                                                                    <div class="overlay-effect bg-color-accent"></div>
                                                                </div>
                                                                <div class="text-wrap">
                                                                    <h5 class="heading"><a href="servicedetails/1">all type building meterial supplayer</a></h5>
                                                                    <p>we provide all type of building materials. what you need to construct your home.</p>
                                                                    <div class="elm-readmore">
                                                                        <a href="servicedetails/1">DETAILS</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div><!-- /.themesflat-image-box -->                                           
                                                                                                </div>
                                            </div><!-- /.themesflat-carousel-box -->                                            
                                            <div class="themesflat-spacer clearfix" data-desktop="45" data-mobile="60" data-smobile="60"></div>
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->
                                </div><!-- /.container -->
                            </div>
                            <!-- END SERVICES -->

                            <!-- ICONBOX -->
                            <div class="row-iconbox bg-row-2">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="themesflat-spacer clearfix" data-desktop="60" data-mobile="60" data-smobile="60"></div>
                                            <div class="themesflat-headings style-1 text-center clearfix">
                                                <h2 class="heading text-white">LEADING CONSTRUCTION</h2>
                                                <div class="sep has-icon width-125 border-color-light clearfix">
                                                    <div class="sep-icon ">
                                                        <span class="sep-icon-before sep-center sep-solid"></span>
                                                        <span class="icon-wrap"><i class="autora-icon-build"></i></span>
                                                        <span class="sep-icon-after sep-center sep-solid"></span>
                                                    </div>
                                                </div>                                                
                                            </div>
                                            <div class="themesflat-spacer clearfix" data-desktop="25" data-mobile="35" data-smobile="35"></div>
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->

                                    <div class="themesflat-row gutter-30 gutter-mobile clearfix">
                                        <div class="col span_1_of_3">
                                            <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="0" data-smobile="35"></div>
                                            <div class="themesflat-icon-box icon-top align-center has-width w95 circle light-bg accent-color style-1 bg-white-column padding-inner clearfix">
                                                <div class="icon-wrap">
                                                    <i class="autora-icon-author"></i>
                                                </div>
                                                <div class="text-wrap">
                                                    <h5 class="heading"><a href="#">OUR MISSION</a></h5>
                                                    <div class="sep clearfix"></div>
                                                    <p class="sub-heading">On every job, we demand the highest quality standards in all our products and services.</p>
                                                </div>
                                            </div><!-- /.themesflat-icon-box -->
                                            <div class="divider h35"></div>                                                                              
                                        </div><!-- /.col-md-3 -->

                                        <div class="col span_1_of_3">
                                            <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="0" data-smobile="35"></div>
                                            <div class="themesflat-icon-box icon-top align-center has-width w95 circle light-bg accent-color style-1 bg-white-column padding-inner clearfix">
                                                <div class="icon-wrap">
                                                    <i class="autora-icon-quality"></i>
                                                </div>
                                                <div class="text-wrap">
                                                    <h5 class="heading"><a href="#">BEST QUALITY</a></h5>
                                                    <div class="sep clearfix"></div>
                                                    <p class="sub-heading">We are committed to meeting the highest quality standards without compromising our.</p>
                                                </div>
                                            </div><!-- /.themesflat-icon-box -->
                                            <div class="divider h35"></div>                                       
                                        </div><!-- /.col-md-3 -->
                                        <div class="col span_1_of_3">
                                            <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="35" data-smobile="35"></div>
                                            <div class="themesflat-icon-box icon-top align-center has-width w95 circle light-bg accent-color style-1 bg-white-column padding-inner clearfix">
                                                <div class="icon-wrap">
                                                    <i class="autora-icon-time"></i>
                                                </div>
                                                <div class="text-wrap">
                                                    <h5 class="heading"><a href="#">ON TIME</a></h5>
                                                    <div class="sep clearfix"></div>
                                                    <p class="sub-heading">We respect the customer’s time and schedule and always complete the projects on time.</p>
                                                </div>
                                            </div><!-- /.themesflat-icon-box -->
                                        </div><!-- /.col-md-3 -->                                        
                                        <div class="col span_1_of_3">
                                            <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="35" data-smobile="35"></div>
                                            <div class="themesflat-icon-box icon-top align-center has-width w95 circle light-bg accent-color style-1 bg-white-column padding-inner clearfix">
                                                <div class="icon-wrap">
                                                    <i class="autora-icon-author"></i>
                                                </div>
                                                <div class="text-wrap">
                                                    <h5 class="heading"><a href="#">EXPERIENCED</a></h5>
                                                    <div class="sep clearfix"></div>
                                                    <p class="sub-heading">With our years of experience you can bet on us to get the job done exactly. Quality Work analysis.</p>
                                                </div>
                                            </div><!-- /.themesflat-icon-box -->
                                        </div><!-- /.col-md-3 -->
                                    </div><!-- /.row -->

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="themesflat-spacer clearfix" data-desktop="80" data-mobile="60" data-smobile="60"></div>
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->
                                </div><!-- /.container -->
                            </div>
                            <!-- END ICONBOX -->

                             <!-- WHYUS -->
                            <div class="row-whyus">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="themesflat-spacer clearfix" data-desktop="61" data-mobile="60" data-smobile="60"></div>
                                            <div class="themesflat-headings style-1 text-center clearfix">
                                                <h2 class="heading">WHY CHOOSE US?</h2>
                                                <div class="sep has-icon width-125 clearfix">
                                                    <div class="sep-icon">
                                                        <span class="sep-icon-before sep-center sep-solid"></span>
                                                        <span class="icon-wrap"><i class="autora-icon-build"></i></span>
                                                        <span class="sep-icon-after sep-center sep-solid"></span>
                                                    </div>
                                                </div>                                                
                                            </div>
                                            <div class="themesflat-spacer clearfix" data-desktop="29" data-mobile="35" data-smobile="35"></div>
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->
                                    <div class="row">
                                        <div class="col-md-6">                                            
                                            <div class="themesflat-content-box clearfix" data-margin="0 31px 0 0" data-mobilemargin="0 0 0 0">
                                                <p class="font-size-16 no-margin">We have best team for constructions building and give best design and model for home designs. </p>
                                                <div class="themesflat-spacer clearfix" data-desktop="37" data-mobile="35" data-smobile="35"></div>
                                                <div class="themesflat-progress style-1 height-10px clearfix">
                                                    <h3 class="title">PARTNERSHIP</h3>
                                                    <div class="perc-wrap">
                                                        <div class="perc"><span>80%</span></div>
                                                    </div>
                                                    <div class="progress-bg" data-percent="80" data-inviewport="yes">
                                                        <div class="progress-animate"></div>
                                                    </div>
                                                </div><!-- /.themesflat-progrees -->
                                                <div class="themesflat-spacer clearfix" data-desktop="25" data-mobile="25" data-smobile="25"></div>
                                                <div class="themesflat-progress style-1 height-10px clearfix">
                                                    <h3 class="title">FULL SUPPORT</h3>
                                                    <div class="perc-wrap">
                                                        <div class="perc"><span>90%</span></div>
                                                    </div>
                                                    <div class="progress-bg" data-percent="90" data-inviewport="yes">
                                                        <div class="progress-animate"></div>
                                                    </div>
                                                </div><!-- /.themesflat-progrees -->
                                                <div class="themesflat-spacer clearfix" data-desktop="26" data-mobile="26" data-smobile="26"></div>
                                                <div class="themesflat-progress style-1 height-10px clearfix">
                                                    <h3 class="title">OPPORTUNITY</h3>
                                                    <div class="perc-wrap">
                                                        <div class="perc"><span>70%</span></div>
                                                    </div>
                                                    <div class="progress-bg" data-percent="70" data-inviewport="yes">
                                                        <div class="progress-animate"></div>
                                                    </div>
                                                </div><!-- /.themesflat-progrees -->
                                            </div><!-- /.themesflat-content-box -->                                                
                                        </div><!-- /.col-md-6 -->

                                        <div class="col-md-6">
                                            <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="0" data-smobile="35"></div>
                                            <div class="themesflat-content-box" data-margin="3px 0 0 10px" data-mobilemargin="0 0 0 0">
                                                <div class="themesflat-accordions style-2 has-icon icon-left iconstyle-2 clearfix">
                                                    <div class="accordion-item active">
                                                        <h3 class="accordion-heading"><span class="inner">Are there any hosting companies you... ?</span></h3>
                                                        <div class="accordion-content">
                                                            <div>Yes we have more than 20 companies products like Shree Cement, Bangar Cement as Like Bazari and other Building Material. </div>
                                                        </div>
                                                    </div><!-- /.accordion-item -->
                                                    <div class="accordion-item">
                                                        <h3 class="accordion-heading"><span class="inner">We use technology to do the job more... ?</span></h3>
                                                        <div class="accordion-content">
                                                            <div>We used Classified Product of Technology like building Design theme and Container of All machinary to the role of All Building construction.</div>
                                                        </div>
                                                    </div><!-- /.accordion-item -->
                                                    <div class="accordion-item ">
                                                        <h3 class="accordion-heading"><span class="inner">Employees are continually trained on safety... ?</span></h3>
                                                        <div class="accordion-content">
                                                            <div>We have Experinced team of employees to be get trained all of Making visibilities of working Area in metal design And Building Design.</div>
                                                        </div>
                                                    </div><!-- /.accordion-item -->
                                                </div><!-- /.themesflat-accordion -->
                                            </div><!-- /.themesflat-content-box -->                                                
                                        </div><!-- /.col-md-6 -->
                                    </div><!-- /.row -->
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="themesflat-spacer clearfix" data-desktop="76" data-mobile="60" data-smobile="60"></div>
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->
                                </div><!-- /.container -->
                            </div>
                            <!-- END WHYUS  -->
                            
                            <!-- REQUEST -->
                            <div class="row-request parallax parallax-3">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 ">
                                            <div class="themesflat-spacer clearfix" data-desktop="82" data-mobile="60" data-smobile="60"></div>
                                            <div class="themesflat-request-box style-1 clearfix">
                                                <div class="inner">
                                                    <div class="themesflat-headings style-1 clearfix">
                                                        <h2 class="heading text-white line-height-normal">REQUEST CALL BACK</h2>
                                                        <div class="sep has-width w80 accent-bg margin-top-13 clearfix"></div>                                               
                                                        <p class="sub-heading margin-top-22 font-size-14 line-height-24 text-white font-weight-400">Would you like to speak to one of our financial advisers over the phone? Just submit your details and we’ll be in touch shortly.</p>
                                                    </div><!-- /.themesflat-heading -->
                                                    <div class="themesflat-contact-form style-1 clearfix">
                                                        <div class="themesflat-spacer clearfix" data-desktop="8" data-mobile="8" data-smobile="8"></div>
                                                        <form method="post" class="contact-form wpcf7-form">
                                                            <span class="wpcf7-form-control-wrap your-name" style="width: 48%;">
                                                                <input type="text" tabindex="1" id="name" name="name" value="" class="wpcf7-form-control" placeholder="Name" required>
                                                            </span>
                                                            <span class="wpcf7-form-control-wrap your-phone" style="width: 48%;">
                                                                <input type="text" tabindex="2" id="phone" name="phone" value="" class="wpcf7-form-control" placeholder="Phone number" required>
                                                            </span>                                                            
                                                            <span class="wpcf7-form-control-wrap your-email" style="width: 48%;">
                                                                <input type="email" tabindex="3" id="email" name="email" value="" class="wpcf7-form-control" placeholder="Email">
                                                            </span>
                                                            <span class="wpcf7-form-control-wrap your-name" style="width: 48%;">
                                                                <input type="text" tabindex="1" id="query" name="query" value="" class="wpcf7-form-control" placeholder="Put Your Query">
                                                            </span>                                                           
                                                            <span class="wrap-submit">
                                                                <button type="button" value="SEND US" class="submit wpcf7-form-control wpcf7-submit" id="sendEmail" >Submit</button>
                                                            </span>                                                            
                                                        </form>
                                                    </div>
                                                </div><!-- /.inner -->
                                            </div><!-- /.themesflat-request-box -->                                           
                                            <div class="themesflat-spacer clearfix" data-desktop="76" data-mobile="60" data-smobile="60"></div>
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->
                                </div><!-- /.container -->
                            </div>
                            <!-- END REQUEST -->

                            <!-- PROJECT -->
                            <div class="row-project clearfix">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="themesflat-spacer clearfix" data-desktop="60" data-mobile="60" data-smobile="60"></div>
                                            <div class="position-relative">
                                                <div class="themesflat-headings style-1 clearfix">
                                                <h2 class="heading ">FEATURED PROJECT</h2>                                          
                                                </div>
                                                <ul class="themesflat-filter style-1 filter-absolute clearfix">
                                                    <li class="active"><a href="#" data-filter="*">All</a></li>
                                                    <li><a href="#" data-filter=".green">GREEN HOUSE</a></li>
                                                    <li><a href="#" data-filter=".architecture">ARCHITECTURE   </a></li>
                                                    <li><a href="#" data-filter=".construction">CONSTRUCTION </a></li>
                                                    <li><a href="#" data-filter=".villa">VILLA</a></li>
                                                    <li><a href="#" data-filter=".building">BUILDING</a></li>
                                                </ul>
                                            </div>                                            
                                            <div class="themesflat-spacer clearfix" data-desktop="40" data-mobile="35" data-smobile="35"></div>
                                            <div class="themesflat-project style-2 isotope-project has-margin mg15 data-effect clearfix">
                                                <div class="project-item green villa">
                                                    <div class="inner">
                                                        <div class="thumb data-effect-item has-effect-icon w40 offset-v-19 offset-h-49">
                                                            <img src="assets/img/project/project-1-370x245.jpg" alt="Image">                                                                    
                                                            <div class="elm-link">
                                                                <a href="#" class="icon-1 icon-search"></a>
                                                                <a href="#" class="icon-1"></a>
                                                            </div>
                                                            <div class="overlay-effect bg-color-3"></div>
                                                        </div>
                                                        <div class="text-wrap">                                                                        
                                                            <h5 class="heading"><a href="#">LAKE MEADOWS APARTMENTS</a></h5>
                                                            <div class="elm-meta">
                                                                <span><a href="#">Green House</a></span>
                                                                <span><a href="#">Villa</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.product-item -->
                                                <div class="project-item architecture building construction">
                                                    <div class="inner">
                                                        <div class="thumb data-effect-item has-effect-icon w40 offset-v-19 offset-h-49">
                                                            <img src="assets/img/project/project-2-370x245.jpg" alt="Image">                                                                    
                                                            <div class="elm-link">
                                                                <a href="#" class="icon-1 icon-search"></a>
                                                                <a href="#" class="icon-1"></a>
                                                            </div>
                                                            <div class="overlay-effect bg-color-3"></div>
                                                        </div>
                                                        <div class="text-wrap">                                                                        
                                                            <h5 class="heading"><a href="#">CAVAL RIDGE MINE PROJECT </a></h5>
                                                            <div class="elm-meta">
                                                                <span><a href="#">Architecture</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.product-item -->
                                                <div class="project-item villa architecture building construction">
                                                    <div class="inner">
                                                        <div class="thumb data-effect-item has-effect-icon w40 offset-v-19 offset-h-49">
                                                            <img src="assets/img/project/project-3-370x245.jpg" alt="Image">                                                                    
                                                            <div class="elm-link">
                                                                <a href="#" class="icon-1 icon-search"></a>
                                                                <a href="#" class="icon-1"></a>
                                                            </div>
                                                            <div class="overlay-effect bg-color-3"></div>
                                                        </div>
                                                        <div class="text-wrap">                                                                        
                                                            <h5 class="heading"><a href="#">GRAM HOTEL MAMZANA, MEWYORK</a></h5>
                                                            <div class="elm-meta">
                                                                <span><a href="#">Green House</a></span>
                                                                <span><a href="#">Villa</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.product-item -->
                                                <div class="project-item green villa">
                                                    <div class="inner">
                                                        <div class="thumb data-effect-item has-effect-icon w40 offset-v-19 offset-h-49">
                                                            <img src="assets/img/project/project-4-370x245.jpg" alt="Image">                                                                    
                                                            <div class="elm-link">
                                                                <a href="#" class="icon-1 icon-search"></a>
                                                                <a href="#" class="icon-1"></a>
                                                            </div>
                                                            <div class="overlay-effect bg-color-3"></div>
                                                        </div>
                                                        <div class="text-wrap">                                                                        
                                                            <h5 class="heading"><a href="#">LAKE MEADOWS APARTMENTS</a></h5>
                                                            <div class="elm-meta">
                                                                <span><a href="#">Green House</a></span>
                                                                <span><a href="#">Villa</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.product-item -->
                                                <div class="project-item architecture building construction">
                                                    <div class="inner">
                                                        <div class="thumb data-effect-item has-effect-icon w40 offset-v-19 offset-h-49">
                                                            <img src="assets/img/project/project-5-370x245.jpg" alt="Image">                                                                    
                                                            <div class="elm-link">
                                                                <a href="#" class="icon-1 icon-search"></a>
                                                                <a href="#" class="icon-1"></a>
                                                            </div>
                                                            <div class="overlay-effect bg-color-3"></div>
                                                        </div>
                                                        <div class="text-wrap">                                                                        
                                                            <h5 class="heading"><a href="#">CAVAL RIDGE MINE PROJECT </a></h5>
                                                            <div class="elm-meta">
                                                                <span><a href="#">Architecture</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.product-item -->
                                                <div class="project-item green">
                                                    <div class="inner">
                                                        <div class="thumb data-effect-item has-effect-icon w40 offset-v-19 offset-h-49">
                                                            <img src="assets/img/project/project-6-370x245.jpg" alt="Image">                                                                    
                                                            <div class="elm-link">
                                                                <a href="#" class="icon-1 icon-search"></a>
                                                                <a href="#" class="icon-1"></a>
                                                            </div>
                                                            <div class="overlay-effect bg-color-3"></div>
                                                        </div>
                                                        <div class="text-wrap">                                                                        
                                                            <h5 class="heading"><a href="#">GRAM HOTEL MAMZANA, MEWYORK</a></h5>
                                                            <div class="elm-meta">
                                                                <span><a href="#">Green House</a></span>
                                                                <span><a href="#">Villa</a></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div><!-- /.product-item -->
                                            </div><!-- /.themesflat-project -->                                           
                                        </div><!-- /.col-md-12 -->
                                    </div><!-- /.row -->
                                </div><!-- /.container-fluid -->
                            </div>
                            <!-- END PROJECT -->
                       </div><!-- /.page-content -->
                    </div><!-- /#inner-content -->
                </div><!-- /#site-content -->
            </div><!-- /#content-wrap -->
        </div><!-- /#main-content -->        <!-- Footer -->
        <footer id="footer" class="clearfix">
            <div id="footer-widgets" class="container">
                <div class="themesflat-row gutter-30">
                    <div class="col span_1_of_4">
                        <div class="widget widget_text">
                            <div class="textwidget">
                                <p>
                                    <img src="/administrator/assets/dist/img/logo/500x50011.png" alt="Best Construction Company In jaipur" width="170" height="34">
                                </p>

                                <p class="margin-bottom-15">We have over 15 years of experience able to help you 24 hours a day.</p>

                                <ul>
                                    <li>
                                        <div class="inner">
                                            <span class="fa fa-map-marker"></span>
                                            <span class="text"> <p>67-A, sindhu nager, pratap nager chouraha, murlipura, jaipur - 302039</p></span>
                                        </div>
                                    </li>

                                    <li>
                                        <div class="inner">
                                            <span class="fa fa-phone"></span>
                                            <span class="text">CALL US : +91 - 99290 94686, +91 - 70146 83732, +91 - 83021 43406</span>
                                        </div>
                                    </li>

                                    <li class="margin-top-7">
                                        <div class="inner">
                                            <span class=" font-size-14 fa fa-envelope"></span>
                                            <span class="text">info@kumawatconstructions.com</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div><!-- /.widget_text -->
                        <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="0" data-smobile="35"></div>
                    </div><!-- /.col -->

                    <div class="col span_1_of_4">
                        <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="35" data-smobile="35"></div>

                        <div class="widget widget_tags">
                            <h2 class="widget-title margin-bottom-30"><span>TAGS</span></h2>
                            <div class="tags-list">
                                <a href="#">Building</a>
                                <a href="#">Smart House</a>
                                <a href="#">Costruction</a>
                                <a href="#">Villa</a>
                                <a href="#">Residential</a>
                                <a href="#">Interior</a>
                                <a href="#">Resort</a>
                                <a href="#">Commercial</a>
                                <a href="#">Top Construction Company</a>
                                <a href="#">Best Design In Construction</a>
                                <a href="#">Eye Catching Designs</a>
                                <a href="#">Flats</a>
                            </div>
                        </div>
                    </div><!-- /.col -->

                    <div class="col span_1_of_4">
                        <div class="themesflat-spacer clearfix" data-desktop="0" data-mobile="35" data-smobile="35"></div>

                        <div class="widget widget_instagram">
                            <h2 class="widget-title margin-bottom-30"><span>INSTAGRAM PHOTOS</span></h2>
                            <div class="instagram-wrap data-effect clearfix col3 g10">
                                
                            
                            </div>
                        </div><!-- /.widget_instagram -->
                    </div><!-- /.col -->
                </div><!-- /.themesflat-row -->
            </div><!-- /#footer-widgets -->
        </footer><!-- /#footer -->       <!-- Bottom -->
        <div id="bottom" class="clearfix has-spacer">
            <div id="bottom-bar-inner" class="container">
                <div class="bottom-bar-inner-wrap">
                    <div class="bottom-bar-content">
                        <div id="copyright">© <span class="text"> Kumawat Construction Company Design by <a href="https://www.gdinfosolution.com" target="_BLANK" class="text-accent">GD INFO SOLUTION</a></span> 
                        </div>
                    </div><!-- /.bottom-bar-content -->

                    <div class="bottom-bar-menu">
                        <ul class="bottom-nav">
                            <li class="menu-item current-menu-item">
                                <a href="index.php">HOME</a>
                            </li>
                            <li class="menu-item">
                                <a href="aboutus">ABOUT US</a>
                            </li>
                            <li class="menu-item">
                                <a href="services">SERVICES</a>
                            </li>
                            <li class="menu-item">
                                <a href="projects">PROJECTS</a>
                            </li>
                            <li class="menu-item">
                                <a href="blog">BLOG</a>
                            </li>
                            <li class="menu-item">
                                <a href="contactus">CONTACT</a>
                            </li>
                        </ul>
                    </div><!-- /.bottom-bar-menu -->
                </div><!-- /.bottom-bar-inner-wrap -->                
            </div><!-- /#bottom-bar-inner -->
        </div><!-- /#bottom -->

    </div><!-- /#page -->
</div><!-- /#wrapper -->

<a id="scroll-top"></a>

<!-- Javascript -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/plugins.js"></script>
<script src="assets/js/tether.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/animsition.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/countto.js"></script>
<script src="assets/js/equalize.min.js"></script>
<script src="assets/js/jquery.isotope.min.js"></script>
<script src="assets/js/owl.carousel2.thumbs.js"></script>
<script src="assets/js/toastr.min.js"></script>

<script src="assets/js/jquery.cookie.js"></script>
<script src="assets/js/shortcodes.js"></script>
<script src="assets/js/main.js"></script>

<!-- Revolution Slider -->
<script src="includes/rev-slider/js/jquery.themepunch.tools.min.js"></script>
<script src="includes/rev-slider/js/jquery.themepunch.revolution.min.js"></script>
<script src="assets/js/rev-slider.js"></script>
<!-- Load Extensions only on Local File Systems ! The following part can be removed on Server for On Demand Loading -->  
<script src="includes/rev-slider/js/extensions/revolution.extension.actions.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.carousel.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.kenburn.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.migration.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.navigation.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.parallax.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.slideanims.min.js"></script>
<script src="includes/rev-slider/js/extensions/revolution.extension.video.min.js"></script>
<script type="text/javascript">
    $(function(){
        $('#sendEmail').on('click', function(e){
            e.preventDefault();
            var name = $("#name").val();
            var phone = $("#phone").val();
            var email = $("#email").val();
            var query = $("#query").val();
            if (name == "") {
                toastr.error('Please Add Your Name');
            }else if(phone == ""){
                toastr.error('Please Add Phone Number');
            }else{   
                $.ajax({
                    url:'includes/Extra/contact.php',
                    type:'post',
                    data:{
                        name: name,
                        phone: phone,
                        email: email,
                        query: query
                    },
                    dataType:'json',
                    success:function(response){
                        if(response.error){
                            toastr.success(response.message);
                        }else{
                            if(response.status == 1){
                                toastr.success(response.message);
                                $("#name").val('');
                                $("#phone").val('');
                                $("#email").val('');
                            }
                        }
                    }
                });
            }
        });
    });
</script>
</body>
</html>

